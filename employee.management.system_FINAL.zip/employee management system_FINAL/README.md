# Mess-Management-System
The Billing and Inventory Management System used in BITS Pilani Messes and Canteen
