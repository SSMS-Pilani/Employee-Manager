--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee` (
  `E_ID` varchar(11) NOT NULL,
  `PASSWORD` varchar(11) NOT NULL,
  `PRIVILEGE` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`E_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `personal_details`;

/*!40101 SET @saved_cs_client  = @@character_set_client */;

/*!40101 SET character_set_client = utf8 */;

CREATE TABLE `personal_details`(
  
`NAME` text default NULL,
  
`Emp_type` text default NULL,
  
`msrn` int(4) default 0,
  
`mess` text default NULL,
  
`GRADE`char(9) default NULL,
  
`father` text default NULL,
   
`mother` text default NULL,
   
`DOB` text default NULL,
   
`EDU` text default NULL,
  
`CURR` text default NULL,
`PER` text default NULL,
`CONTACT`VARCHAR(11) default NULL,
   
`EMERGENCY`VARCHAR(11) default NULL,
   
`EXPERIENCE` int(4) default NULL,
   
`Marital` text default NULL ,
   
`spouse` text default NULL,
   
`NATIONAL`text default NULL,
   
`LANGUAGE`text default NULL,
   
`JOINING` text default NULL,

PRIMARY KEY(`msrn`)

)ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Table structure for table `dependant`
--

DROP TABLE IF EXISTS `dependant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dependant` (
  `NAME_dependant` text NOT NULL,
  `gender` text DEFAULT NULL,
  `relation` text DEFAULT NULL,
  `msrn`int(4) NOT NULL,
  `age`int(4) NOT NULL,
  `occupation`text NOT NULL,
  `EDU_dependant` text NOT NULL,
  `school`text NOT NULL,
  `year_of_study`varchar(11) NOT NULL,
   KEY `personal_details_msrn_fk` (`msrn`),
  CONSTRAINT `personal_details_msrn_fk`FOREIGN KEY (`msrn`) REFERENCES `personal_details` (`msrn`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Table structure for table `leaves`
--

DROP TABLE IF EXISTS `leaves`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `leaves` (
  `NAME` text NOT NULL,
  `msrn` int(4) NOT NULL,
  `casual_leaves` int(4) NOT NULL,
  `medical_leaves`int(4) NOT NULL,
   primary key(`msrn`),
   KEY `leaves_msrn_fk` (`msrn`),
   CONSTRAINT `leaves_msrn_fk` FOREIGN KEY (`msrn`) REFERENCES `personal_details` (`msrn`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

