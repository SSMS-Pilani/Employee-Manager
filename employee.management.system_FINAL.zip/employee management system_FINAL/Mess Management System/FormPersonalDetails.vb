﻿



Imports MySql.Data.MySqlClient
Imports System.IO
Imports System.Data
Imports System.Reflection
Imports iTextSharp.text
Imports iTextSharp.text.pdf


Public Class FormPersonalDetails
    Dim conn As New connection
    Dim swap As String
    Private Sub FormPersonalDetails_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.KeyPreview = True
        TextBox2.Focus()
    End Sub

    Private Sub TextBox2_keypress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox2.KeyPress
        If Asc(e.KeyChar) = Keys.Enter Then
            TextBox2.ReadOnly = True
        End If
    End Sub

    Private Sub TextBox4_KEYPRESS(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox4.KeyPress
        If Asc(e.KeyChar) = Keys.Enter Then
            TextBox4.ReadOnly = True
        End If
    End Sub

    Private Sub TextBox3_KEYPRESS(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox3.KeyPress
        If Asc(e.KeyChar) = Keys.Enter Then
            TextBox3.ReadOnly = True
        End If
    End Sub


    Private Sub RichTextBox1_keypress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles RichTextBox1.KeyPress
        If Asc(e.KeyChar) = Keys.Enter Then
            RichTextBox1.ReadOnly = True
        End If
    End Sub
    Private Sub RichTextBox3_keypress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles RichTextBox3.KeyPress
        If Asc(e.KeyChar) = Keys.Enter Then
            RichTextBox3.ReadOnly = True
        End If
    End Sub
    Private Sub RichTextBox2_keypress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles RichTextBox2.KeyPress
        If Asc(e.KeyChar) = Keys.Enter Then
            RichTextBox2.ReadOnly = True
        End If
    End Sub


    Private Sub TextBox6_KEYPRESS(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox6.KeyPress
        If Asc(e.KeyChar) = Keys.Enter Then
            TextBox6.ReadOnly = True
        End If
    End Sub

    Private Sub TextBox5_KEYPRESS(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox5.KeyPress
        If Asc(e.KeyChar) = Keys.Enter Then
            TextBox5.ReadOnly = True
        End If
    End Sub

    Private Sub TextBox7_KEYPRESS(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox7.KeyPress
        If Asc(e.KeyChar) = Keys.Enter Then
            TextBox7.ReadOnly = True
        End If
    End Sub


    Private Sub TextBox8_KEYPRESS(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox8.KeyPress
        If Asc(e.KeyChar) = Keys.Enter Then
            TextBox8.ReadOnly = True
        End If

    End Sub

    Private Sub TextBox9_KEYPRESS(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox9.KeyPress
        If Asc(e.KeyChar) = Keys.Enter Then
            TextBox9.ReadOnly = True
        End If

    End Sub
    Private Sub TextBox10_KEYPRESS(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox10.KeyPress
        If Asc(e.KeyChar) = Keys.Enter Then
            TextBox10.ReadOnly = True
        End If

    End Sub



    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton2.CheckedChanged
        Dim temp As String = "Permanent"
        swap = temp


    End Sub


    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged
        Dim temp As String = "Temporary"
        swap = temp
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            conn.connect()
            Dim dr As MySqlDataReader
            Dim query As String
            query = "Insert into personal_details values ('" + TextBox1.Text + "','" + swap + "' ,'" + TextBox2.Text + "','" + ListBox2.Text + "','" + ListBox1.Text + "','" + TextBox4.Text + "','" + TextBox3.Text + "','" + DateTimePicker1.Text + "','" + RichTextBox1.Text + "','" + RichTextBox3.Text + "','" + RichTextBox2.Text + "','" + TextBox6.Text + "','" + TextBox5.Text + "','" + TextBox7.Text + "','" + ListBox3.Text + "','" + TextBox8.Text + "','" + TextBox9.Text + "','" + TextBox10.Text + "','" + DateTimePicker2.Text + "')"
            Dim comm2 As New MySqlCommand(query, conn.conn)
            dr = comm2.ExecuteReader
            MsgBox("Saved Successfully")

            Me.Close()

        Catch de As MySqlException
            MsgBox("Error Occured! Please Try Again!")
            MsgBox(de.Message.ToString)
            TextBox1.Text = ""
        End Try

    End Sub


   

    Private Sub TextBox11_keypress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox11.KeyPress
        If Asc(e.KeyChar) = Keys.Enter Then
            TextBox11.ReadOnly = True
            Try
                conn.connect()
                Dim dr As MySqlDataReader
                Dim query As String
                query = "Select*from personal_details where msrn='" + TextBox11.Text + "'"
                Dim comm2 As New MySqlCommand(query, conn.conn)
                dr = comm2.ExecuteReader
                If dr.Read() And Not IsDBNull(dr.Item(0)) Then
                    TextBox1.Text = dr.Item("NAME")
                    TextBox2.Text = dr.Item("msrn")
                    ListBox2.Text = dr.Item("mess")
                    ListBox1.Text = dr.Item("grade")
                    TextBox4.Text = dr.Item("father")
                    TextBox3.Text = dr.Item("mother")
                    DateTimePicker1.Text = dr.Item("DOB")
                    RichTextBox1.Text = dr.Item("EDU")
                    RichTextBox3.Text = dr.Item("CURR")
                    RichTextBox2.Text = dr.Item("PER")
                    TextBox6.Text = dr.Item("CONTACT")
                    TextBox5.Text = dr.Item("EMERGENCY")
                    TextBox7.Text = dr.Item("EXPERIENCE")
                    ListBox3.Text = dr.Item("MARITAL")
                    TextBox8.Text = dr.Item("SPOUSE")
                    TextBox9.Text = dr.Item("NATIONAL")
                    TextBox10.Text = dr.Item("LANGUAGE")
                    DateTimePicker2.Text = dr.Item("JOINING")

                End If
            Catch de As MySqlException
                MsgBox("Error Occured! Please Try Again!")
                MsgBox(de.Message.ToString)
                TextBox11.Text = ""
            End Try
        End If
    End Sub


    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        formpdfgenerator.show()
    End Sub
End Class
        


