﻿
Imports MySql.Data.MySqlClient
Imports System.IO
Imports System.Data
Imports System.Reflection
Imports iTextSharp.text
Imports iTextSharp.text.pdf
Public Class formpdfgenerator

    Dim conn As New connection
    Dim filename As Object
    Private Sub formpdfgenerator_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TextBox11.Focus()
    End Sub
    Private Sub fill()

        Try
            conn.connect()
            Dim query As String
            query = "SELECT * from personal_details where msrn='" + TextBox11.Text + "'"
            Dim DR As MySqlDataReader
            Dim comm As New MySqlCommand(query, conn.conn)
            DR = comm.ExecuteReader()
            Dim DT As New DataTable
            DT.Load(DR)
            DataGridView1.DataSource = DT
            DR.Close()
        Catch ex As Exception
            MsgBox(ex.Message.ToString)
        End Try
        filename = TextBox11.Text + ".pdf"

    End Sub

    Private Sub textbox11_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox11.KeyPress
        If Asc(e.KeyChar) = Keys.Enter Then
            TextBox11.ReadOnly = True
            fill()
        'Creating iTextSharp Table from the DataTable data

        End If
    End Sub


    Private Sub btnExportPDF_Click(sender As Object, e As EventArgs) Handles btnExportPDF.Click
        MsgBox("work")

        Dim pdfTable As New PdfPTable(DataGridView1.ColumnCount)
        pdfTable.DefaultCell.Padding = 1
        pdfTable.WidthPercentage = 100
        pdfTable.HorizontalAlignment = Element.ALIGN_LEFT
        pdfTable.DefaultCell.BorderWidth = 1

        'Adding Header row
        For Each column As DataGridViewColumn In DataGridView1.Columns
            Dim cell As New PdfPCell(New Phrase(column.HeaderText))
            pdfTable.AddCell(cell)
        Next

        'Adding DataRow
        For Each row As DataGridViewRow In DataGridView1.Rows
            For Each cell As DataGridViewCell In row.Cells
                pdfTable.AddCell(cell.Value.ToString())
            Next
        Next

        'Exporting to PDF
        Dim folderPath As String = "C:\PDFs\"
        If Not Directory.Exists(folderPath) Then
            Directory.CreateDirectory(folderPath)
        End If
        Using stream As New FileStream(folderPath & filename, FileMode.Create)
            Dim pdfDoc As New Document(PageSize.A2, 10.0F, 10.0F, 10.0F, 0.0F)
            PdfWriter.GetInstance(pdfDoc, stream)
            pdfDoc.Open()
            pdfDoc.Add(pdfTable)
            pdfDoc.Close()
            stream.Close()
        End Using
        MsgBox("successfully")
    End Sub
End Class