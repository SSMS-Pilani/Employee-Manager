﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class formControlP
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Grub_Signings = New System.Windows.Forms.Button()
        Me.Extras = New System.Windows.Forms.Button()
        Me.Monthly_Bill = New System.Windows.Forms.Button()
        Me.Add_item = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.SystemColors.ControlLight
        Me.GroupBox1.Controls.Add(Me.Grub_Signings)
        Me.GroupBox1.Controls.Add(Me.Extras)
        Me.GroupBox1.Controls.Add(Me.Monthly_Bill)
        Me.GroupBox1.Controls.Add(Me.Add_item)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 10)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(867, 248)
        Me.GroupBox1.TabIndex = 14
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Control Panel"
        '
        'Grub_Signings
        '
        Me.Grub_Signings.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Grub_Signings.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!)
        Me.Grub_Signings.Location = New System.Drawing.Point(490, 104)
        Me.Grub_Signings.Name = "Grub_Signings"
        Me.Grub_Signings.Size = New System.Drawing.Size(215, 49)
        Me.Grub_Signings.TabIndex = 21
        Me.Grub_Signings.Text = "Dependant details"
        Me.Grub_Signings.UseVisualStyleBackColor = True
        '
        'Extras
        '
        Me.Extras.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Extras.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!)
        Me.Extras.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Extras.Location = New System.Drawing.Point(280, 19)
        Me.Extras.Name = "Extras"
        Me.Extras.Size = New System.Drawing.Size(153, 56)
        Me.Extras.TabIndex = 11
        Me.Extras.Text = "Personal Details" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "(F5)"
        Me.Extras.UseVisualStyleBackColor = True
        '
        'Monthly_Bill
        '
        Me.Monthly_Bill.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Monthly_Bill.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!)
        Me.Monthly_Bill.Location = New System.Drawing.Point(263, 177)
        Me.Monthly_Bill.Name = "Monthly_Bill"
        Me.Monthly_Bill.Size = New System.Drawing.Size(215, 49)
        Me.Monthly_Bill.TabIndex = 20
        Me.Monthly_Bill.Text = "Edit Details"
        Me.Monthly_Bill.UseVisualStyleBackColor = True
        '
        'Add_item
        '
        Me.Add_item.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Add_item.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.25!)
        Me.Add_item.Location = New System.Drawing.Point(96, 102)
        Me.Add_item.Name = "Add_item"
        Me.Add_item.Size = New System.Drawing.Size(133, 50)
        Me.Add_item.TabIndex = 12
        Me.Add_item.Text = "Leaves"
        Me.Add_item.UseVisualStyleBackColor = True
        '
        'formControlP
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLight
        Me.CausesValidation = False
        Me.ClientSize = New System.Drawing.Size(788, 257)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "formControlP"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Control Panel"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Extras As System.Windows.Forms.Button
    Friend WithEvents Add_item As System.Windows.Forms.Button
    Friend WithEvents Grub_Signings As System.Windows.Forms.Button
    Friend WithEvents Monthly_Bill As System.Windows.Forms.Button
End Class
