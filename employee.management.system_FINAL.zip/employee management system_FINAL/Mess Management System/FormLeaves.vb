﻿Imports MySql.Data.MySqlClient
Public Class FormLeaves
    Dim conn As New connection
    Dim conn1 As New connection

    Private Sub FormLeaves_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TextBox2.Focus()
    End Sub
    Private Sub TextBox2_keypress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox2.KeyPress
        If Asc(e.KeyChar) = Keys.Enter Then
            TextBox2.ReadOnly = True
            Try
                conn.connect()
                Dim dr As MySqlDataReader
                Dim query As String
                query = "Select * from personal_details where msrn='" + TextBox2.Text + "'"
                Dim comm2 As New MySqlCommand(query, conn.conn)
                dr = comm2.ExecuteReader
                If dr.Read() And Not IsDBNull(dr.Item(0)) Then
                    TextBox1.Text = dr.Item("NAME")
                ElseIf IsDBNull(dr.Item(0)) Then
                    MsgBox("This MSRN does not exist")
                End If
            Catch de As MySqlException
                MsgBox("Error Occured! Please Try Again!")
                MsgBox(de.Message.ToString)
                TextBox1.Text = ""
            End Try
        End If
    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            conn.connect()
            Dim dr As MySqlDataReader
            Dim query As String
            query = "Insert into leaves values ('" + TextBox1.Text + "' ,'" + TextBox2.Text + "','" + NumericUpDown2.Text + " ','" + NumericUpDown1.Text + "')"
            Dim comm2 As New MySqlCommand(query, conn.conn)
            dr = comm2.ExecuteReader
            MsgBox("Saved Successfully")
            Me.Close()
        Catch de As MySqlException
            MsgBox("Error Occured! Please Try Again!")
            MsgBox(de.Message.ToString)
            TextBox1.Text = ""
        End Try

    End Sub
    Private Sub TET_keypress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TET.KeyPress
        If Asc(e.KeyChar) = Keys.Enter Then
            TET.ReadOnly = True
            Try
                conn.connect()
                Dim dr As MySqlDataReader
                Dim query As String
                query = "Select * from leaves where msrn='" + TET.Text + "'"
                Dim comm2 As New MySqlCommand(query, conn.conn)
                dr = comm2.ExecuteReader
                If dr.Read() And Not IsDBNull(dr.Item(0)) Then
                    TextBox2.Text = dr.Item("msrn")
                    TextBox1.Text = dr.Item("NAME")
                    NumericUpDown1.Text = dr.Item("medical_leaves")
                    NumericUpDown2.Text = dr.Item("casual_leaves")


                ElseIf IsDBNull(dr.Item(0)) Then
                    MsgBox("This MSRN does not exist")
                End If
            Catch de As MySqlException
                MsgBox("Error Occured! Please Try Again!")
                MsgBox(de.Message.ToString)
                TET.Text = ""
            End Try
        End If
    End Sub


    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Try
            conn.connect()
            Dim dr As MySqlDataReader
            Dim dr1 As MySqlDataReader
            Dim query1 As String
            Dim query2 As String

            query1 = "update leaves set medical_leaves='" + NumericUpDown1.Text + "' "
            query2 = "update leaves set casual_leaves='" + NumericUpDown2.Text + "' "

            Dim comm2 As New MySqlCommand(query1, conn.conn)
            dr = comm2.ExecuteReader
            dr.Close()

            Dim comm3 As New MySqlCommand(query2, conn.conn)
            dr1 = comm3.ExecuteReader
        Catch de As MySqlException
            MsgBox("Error Occured! Please Try Again!")
            MsgBox(de.Message.ToString)
            TET.Text = ""
        End Try
    End Sub
End Class