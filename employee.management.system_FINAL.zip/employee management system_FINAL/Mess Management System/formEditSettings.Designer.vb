﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class formEditSettings
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ButtonConfirm = New System.Windows.Forms.Button()
        Me.ButtonCancel = New System.Windows.Forms.Button()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.tbRebate_Min_Days = New System.Windows.Forms.TextBox()
        Me.tbMax_Days_Delete_Entries = New System.Windows.Forms.TextBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.tbQuery_ON = New System.Windows.Forms.CheckBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.tbCash_ID = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.cbCash_On = New System.Windows.Forms.CheckBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cbBy_Scanner_Only = New System.Windows.Forms.CheckBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.tbPhotos_Location = New System.Windows.Forms.TextBox()
        Me.tbExtras_Location = New System.Windows.Forms.TextBox()
        Me.tbMess_Name = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.TabControl2 = New System.Windows.Forms.TabControl()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.tbDB_Name = New System.Windows.Forms.TextBox()
        Me.ButtonControlP = New System.Windows.Forms.Button()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.tbMessShortName = New System.Windows.Forms.TextBox()
        Me.TabPage3.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabControl2.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.SuspendLayout()
        '
        'ButtonConfirm
        '
        Me.ButtonConfirm.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.25!)
        Me.ButtonConfirm.Location = New System.Drawing.Point(16, 221)
        Me.ButtonConfirm.Name = "ButtonConfirm"
        Me.ButtonConfirm.Size = New System.Drawing.Size(111, 46)
        Me.ButtonConfirm.TabIndex = 18
        Me.ButtonConfirm.Text = "Confirm"
        Me.ButtonConfirm.UseVisualStyleBackColor = True
        '
        'ButtonCancel
        '
        Me.ButtonCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.25!)
        Me.ButtonCancel.Location = New System.Drawing.Point(165, 221)
        Me.ButtonCancel.Name = "ButtonCancel"
        Me.ButtonCancel.Size = New System.Drawing.Size(111, 46)
        Me.ButtonCancel.TabIndex = 19
        Me.ButtonCancel.Text = "Cancel"
        Me.ButtonCancel.UseVisualStyleBackColor = True
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.Label5)
        Me.TabPage3.Controls.Add(Me.Label6)
        Me.TabPage3.Controls.Add(Me.tbRebate_Min_Days)
        Me.TabPage3.Controls.Add(Me.tbMax_Days_Delete_Entries)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(410, 153)
        Me.TabPage3.TabIndex = 3
        Me.TabPage3.Text = "Billing and Other Settings"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(16, 73)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(93, 13)
        Me.Label5.TabIndex = 15
        Me.Label5.Text = "Rebate_Min_days"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(16, 33)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(132, 13)
        Me.Label6.TabIndex = 14
        Me.Label6.Text = "Max_Days_Delete_Entries"
        '
        'tbRebate_Min_Days
        '
        Me.tbRebate_Min_Days.Location = New System.Drawing.Point(188, 68)
        Me.tbRebate_Min_Days.Name = "tbRebate_Min_Days"
        Me.tbRebate_Min_Days.Size = New System.Drawing.Size(207, 20)
        Me.tbRebate_Min_Days.TabIndex = 13
        '
        'tbMax_Days_Delete_Entries
        '
        Me.tbMax_Days_Delete_Entries.Location = New System.Drawing.Point(188, 31)
        Me.tbMax_Days_Delete_Entries.Name = "tbMax_Days_Delete_Entries"
        Me.tbMax_Days_Delete_Entries.Size = New System.Drawing.Size(207, 20)
        Me.tbMax_Days_Delete_Entries.TabIndex = 12
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.tbQuery_ON)
        Me.TabPage2.Controls.Add(Me.Label1)
        Me.TabPage2.Controls.Add(Me.tbCash_ID)
        Me.TabPage2.Controls.Add(Me.Label7)
        Me.TabPage2.Controls.Add(Me.cbCash_On)
        Me.TabPage2.Controls.Add(Me.Label3)
        Me.TabPage2.Controls.Add(Me.cbBy_Scanner_Only)
        Me.TabPage2.Controls.Add(Me.Label2)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(410, 153)
        Me.TabPage2.TabIndex = 2
        Me.TabPage2.Text = "Other Settings"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'tbQuery_ON
        '
        Me.tbQuery_ON.AutoSize = True
        Me.tbQuery_ON.Location = New System.Drawing.Point(193, 118)
        Me.tbQuery_ON.Name = "tbQuery_ON"
        Me.tbQuery_ON.Size = New System.Drawing.Size(118, 17)
        Me.tbQuery_ON.TabIndex = 28
        Me.tbQuery_ON.Text = "Select to set TRUE"
        Me.tbQuery_ON.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(18, 118)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(54, 13)
        Me.Label1.TabIndex = 27
        Me.Label1.Text = "Query ON"
        '
        'tbCash_ID
        '
        Me.tbCash_ID.Location = New System.Drawing.Point(192, 85)
        Me.tbCash_ID.Name = "tbCash_ID"
        Me.tbCash_ID.Size = New System.Drawing.Size(207, 20)
        Me.tbCash_ID.TabIndex = 26
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(19, 88)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(48, 13)
        Me.Label7.TabIndex = 25
        Me.Label7.Text = "Cash_ID"
        '
        'cbCash_On
        '
        Me.cbCash_On.AutoSize = True
        Me.cbCash_On.Location = New System.Drawing.Point(192, 51)
        Me.cbCash_On.Name = "cbCash_On"
        Me.cbCash_On.Size = New System.Drawing.Size(118, 17)
        Me.cbCash_On.TabIndex = 24
        Me.cbCash_On.Text = "Select to set TRUE"
        Me.cbCash_On.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(17, 51)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(50, 13)
        Me.Label3.TabIndex = 23
        Me.Label3.Text = "Cash ON"
        '
        'cbBy_Scanner_Only
        '
        Me.cbBy_Scanner_Only.AutoSize = True
        Me.cbBy_Scanner_Only.Location = New System.Drawing.Point(192, 18)
        Me.cbBy_Scanner_Only.Name = "cbBy_Scanner_Only"
        Me.cbBy_Scanner_Only.Size = New System.Drawing.Size(118, 17)
        Me.cbBy_Scanner_Only.TabIndex = 22
        Me.cbBy_Scanner_Only.Text = "Select to set TRUE"
        Me.cbBy_Scanner_Only.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(15, 16)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(90, 13)
        Me.Label2.TabIndex = 21
        Me.Label2.Text = "By_Scanner_only"
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Controls.Add(Me.tbPhotos_Location)
        Me.TabPage1.Controls.Add(Me.tbExtras_Location)
        Me.TabPage1.Controls.Add(Me.tbMess_Name)
        Me.TabPage1.Controls.Add(Me.Label8)
        Me.TabPage1.Controls.Add(Me.Label10)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(410, 153)
        Me.TabPage1.TabIndex = 1
        Me.TabPage1.Text = "Mess Settings"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(14, 80)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(84, 13)
        Me.Label4.TabIndex = 27
        Me.Label4.Text = "Photos Location"
        '
        'tbPhotos_Location
        '
        Me.tbPhotos_Location.Location = New System.Drawing.Point(137, 77)
        Me.tbPhotos_Location.Name = "tbPhotos_Location"
        Me.tbPhotos_Location.Size = New System.Drawing.Size(207, 20)
        Me.tbPhotos_Location.TabIndex = 26
        '
        'tbExtras_Location
        '
        Me.tbExtras_Location.Location = New System.Drawing.Point(137, 44)
        Me.tbExtras_Location.Name = "tbExtras_Location"
        Me.tbExtras_Location.Size = New System.Drawing.Size(207, 20)
        Me.tbExtras_Location.TabIndex = 25
        '
        'tbMess_Name
        '
        Me.tbMess_Name.Location = New System.Drawing.Point(137, 9)
        Me.tbMess_Name.Name = "tbMess_Name"
        Me.tbMess_Name.Size = New System.Drawing.Size(207, 20)
        Me.tbMess_Name.TabIndex = 8
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(12, 47)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(83, 13)
        Me.Label8.TabIndex = 24
        Me.Label8.Text = "Extras_Location"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(12, 13)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(66, 13)
        Me.Label10.TabIndex = 7
        Me.Label10.Text = "Mess_Name"
        '
        'TabControl2
        '
        Me.TabControl2.Controls.Add(Me.TabPage1)
        Me.TabControl2.Controls.Add(Me.TabPage2)
        Me.TabControl2.Controls.Add(Me.TabPage3)
        Me.TabControl2.Controls.Add(Me.TabPage4)
        Me.TabControl2.Location = New System.Drawing.Point(12, 14)
        Me.TabControl2.Name = "TabControl2"
        Me.TabControl2.SelectedIndex = 0
        Me.TabControl2.Size = New System.Drawing.Size(418, 179)
        Me.TabControl2.TabIndex = 22
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.Label11)
        Me.TabPage4.Controls.Add(Me.tbMessShortName)
        Me.TabPage4.Controls.Add(Me.Label9)
        Me.TabPage4.Controls.Add(Me.tbDB_Name)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(410, 153)
        Me.TabPage4.TabIndex = 4
        Me.TabPage4.Text = "Database Settings"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(45, 25)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(98, 13)
        Me.Label9.TabIndex = 1
        Me.Label9.Text = "DATABASE NAME"
        '
        'tbDB_Name
        '
        Me.tbDB_Name.Location = New System.Drawing.Point(174, 21)
        Me.tbDB_Name.Name = "tbDB_Name"
        Me.tbDB_Name.Size = New System.Drawing.Size(205, 20)
        Me.tbDB_Name.TabIndex = 0
        '
        'ButtonControlP
        '
        Me.ButtonControlP.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.25!)
        Me.ButtonControlP.Location = New System.Drawing.Point(314, 221)
        Me.ButtonControlP.Name = "ButtonControlP"
        Me.ButtonControlP.Size = New System.Drawing.Size(111, 46)
        Me.ButtonControlP.TabIndex = 19
        Me.ButtonControlP.Text = "Control Panel"
        Me.ButtonControlP.UseVisualStyleBackColor = True
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(44, 70)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(120, 13)
        Me.Label11.TabIndex = 3
        Me.Label11.Text = "DATABASE ShortName"
        '
        'tbMessShortName
        '
        Me.tbMessShortName.Location = New System.Drawing.Point(174, 66)
        Me.tbMessShortName.Name = "tbMessShortName"
        Me.tbMessShortName.Size = New System.Drawing.Size(205, 20)
        Me.tbMessShortName.TabIndex = 2
        '
        'formEditSettings
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(442, 301)
        Me.Controls.Add(Me.TabControl2)
        Me.Controls.Add(Me.ButtonControlP)
        Me.Controls.Add(Me.ButtonCancel)
        Me.Controls.Add(Me.ButtonConfirm)
        Me.Name = "formEditSettings"
        Me.Text = "Admin Settings"
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabControl2.ResumeLayout(False)
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ButtonConfirm As System.Windows.Forms.Button
    Friend WithEvents ButtonCancel As System.Windows.Forms.Button
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents tbRebate_Min_Days As System.Windows.Forms.TextBox
    Friend WithEvents tbMax_Days_Delete_Entries As System.Windows.Forms.TextBox
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents tbQuery_ON As System.Windows.Forms.CheckBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents tbCash_ID As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents cbCash_On As System.Windows.Forms.CheckBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents cbBy_Scanner_Only As System.Windows.Forms.CheckBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents tbPhotos_Location As System.Windows.Forms.TextBox
    Friend WithEvents tbExtras_Location As System.Windows.Forms.TextBox
    Friend WithEvents tbMess_Name As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents TabControl2 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents tbDB_Name As System.Windows.Forms.TextBox
    Friend WithEvents ButtonControlP As System.Windows.Forms.Button
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents tbMessShortName As System.Windows.Forms.TextBox
End Class
