﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormPersonalDetails
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Names = New System.Windows.Forms.Label()
        Me.Employement = New System.Windows.Forms.Label()
        Me.MSRN = New System.Windows.Forms.Label()
        Me.current = New System.Windows.Forms.Label()
        Me.grade = New System.Windows.Forms.Label()
        Me.father = New System.Windows.Forms.Label()
        Me.Mother = New System.Windows.Forms.Label()
        Me.DOB = New System.Windows.Forms.Label()
        Me.Education = New System.Windows.Forms.Label()
        Me.curr = New System.Windows.Forms.Label()
        Me.Perma = New System.Windows.Forms.Label()
        Me.Years = New System.Windows.Forms.Label()
        Me.Contact = New System.Windows.Forms.Label()
        Me.Emer = New System.Windows.Forms.Label()
        Me.Marry = New System.Windows.Forms.Label()
        Me.Nam = New System.Windows.Forms.Label()
        Me.National = New System.Windows.Forms.Label()
        Me.Lang = New System.Windows.Forms.Label()
        Me.join = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox2 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox3 = New System.Windows.Forms.RichTextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.DateTimePicker2 = New System.Windows.Forms.DateTimePicker()
        Me.ListBox3 = New System.Windows.Forms.ListBox()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.ListBox2 = New System.Windows.Forms.ListBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Names
        '
        Me.Names.AutoSize = True
        Me.Names.Location = New System.Drawing.Point(0, 9)
        Me.Names.Name = "Names"
        Me.Names.Size = New System.Drawing.Size(38, 13)
        Me.Names.TabIndex = 0
        Me.Names.Text = "Name:"
        '
        'Employement
        '
        Me.Employement.AutoSize = True
        Me.Employement.Location = New System.Drawing.Point(0, 609)
        Me.Employement.Name = "Employement"
        Me.Employement.Size = New System.Drawing.Size(100, 13)
        Me.Employement.TabIndex = 1
        Me.Employement.Text = "Employement Type:"
        '
        'MSRN
        '
        Me.MSRN.AutoSize = True
        Me.MSRN.Location = New System.Drawing.Point(0, 39)
        Me.MSRN.Name = "MSRN"
        Me.MSRN.Size = New System.Drawing.Size(88, 13)
        Me.MSRN.TabIndex = 2
        Me.MSRN.Text = "MSRN/CSWRN:"
        '
        'current
        '
        Me.current.AutoSize = True
        Me.current.Location = New System.Drawing.Point(0, 74)
        Me.current.Name = "current"
        Me.current.Size = New System.Drawing.Size(132, 13)
        Me.current.TabIndex = 3
        Me.current.Text = "CURRENTLY WORKING:"
        '
        'grade
        '
        Me.grade.AutoSize = True
        Me.grade.Location = New System.Drawing.Point(0, 102)
        Me.grade.Name = "grade"
        Me.grade.Size = New System.Drawing.Size(39, 13)
        Me.grade.TabIndex = 4
        Me.grade.Text = "Grade:"
        '
        'father
        '
        Me.father.AutoSize = True
        Me.father.Location = New System.Drawing.Point(0, 136)
        Me.father.Name = "father"
        Me.father.Size = New System.Drawing.Size(78, 13)
        Me.father.TabIndex = 5
        Me.father.Text = "Father's Name:"
        '
        'Mother
        '
        Me.Mother.AutoSize = True
        Me.Mother.Location = New System.Drawing.Point(0, 164)
        Me.Mother.Name = "Mother"
        Me.Mother.Size = New System.Drawing.Size(81, 13)
        Me.Mother.TabIndex = 6
        Me.Mother.Text = "Mother's Name:"
        '
        'DOB
        '
        Me.DOB.AutoSize = True
        Me.DOB.Location = New System.Drawing.Point(0, 190)
        Me.DOB.Name = "DOB"
        Me.DOB.Size = New System.Drawing.Size(69, 13)
        Me.DOB.TabIndex = 7
        Me.DOB.Text = "Date of Birth:"
        '
        'Education
        '
        Me.Education.AutoSize = True
        Me.Education.Location = New System.Drawing.Point(0, 223)
        Me.Education.Name = "Education"
        Me.Education.Size = New System.Drawing.Size(127, 13)
        Me.Education.TabIndex = 8
        Me.Education.Text = "Educational Qualification:"
        '
        'curr
        '
        Me.curr.AutoSize = True
        Me.curr.Location = New System.Drawing.Point(0, 283)
        Me.curr.Name = "curr"
        Me.curr.Size = New System.Drawing.Size(85, 13)
        Me.curr.TabIndex = 9
        Me.curr.Text = "Current Address:"
        '
        'Perma
        '
        Me.Perma.AutoSize = True
        Me.Perma.Location = New System.Drawing.Point(-3, 328)
        Me.Perma.Name = "Perma"
        Me.Perma.Size = New System.Drawing.Size(102, 13)
        Me.Perma.TabIndex = 10
        Me.Perma.Text = "Permanent Address:"
        '
        'Years
        '
        Me.Years.AutoSize = True
        Me.Years.Location = New System.Drawing.Point(1, 451)
        Me.Years.Name = "Years"
        Me.Years.Size = New System.Drawing.Size(105, 13)
        Me.Years.TabIndex = 11
        Me.Years.Text = "Years of Experience:"
        '
        'Contact
        '
        Me.Contact.AutoSize = True
        Me.Contact.Location = New System.Drawing.Point(1, 393)
        Me.Contact.Name = "Contact"
        Me.Contact.Size = New System.Drawing.Size(87, 13)
        Me.Contact.TabIndex = 12
        Me.Contact.Text = "Contact Number:"
        '
        'Emer
        '
        Me.Emer.AutoSize = True
        Me.Emer.Location = New System.Drawing.Point(-1, 419)
        Me.Emer.Name = "Emer"
        Me.Emer.Size = New System.Drawing.Size(143, 13)
        Me.Emer.TabIndex = 13
        Me.Emer.Text = "Emergency Contact Number:"
        '
        'Marry
        '
        Me.Marry.AutoSize = True
        Me.Marry.Location = New System.Drawing.Point(0, 581)
        Me.Marry.Name = "Marry"
        Me.Marry.Size = New System.Drawing.Size(74, 13)
        Me.Marry.TabIndex = 14
        Me.Marry.Text = "Marital Status:"
        '
        'Nam
        '
        Me.Nam.AutoSize = True
        Me.Nam.Location = New System.Drawing.Point(-1, 480)
        Me.Nam.Name = "Nam"
        Me.Nam.Size = New System.Drawing.Size(89, 13)
        Me.Nam.TabIndex = 16
        Me.Nam.Text = "Name of Spouse:"
        '
        'National
        '
        Me.National.AutoSize = True
        Me.National.Location = New System.Drawing.Point(1, 506)
        Me.National.Name = "National"
        Me.National.Size = New System.Drawing.Size(59, 13)
        Me.National.TabIndex = 17
        Me.National.Text = "Nationality:"
        '
        'Lang
        '
        Me.Lang.AutoSize = True
        Me.Lang.Location = New System.Drawing.Point(1, 536)
        Me.Lang.Name = "Lang"
        Me.Lang.Size = New System.Drawing.Size(99, 13)
        Me.Lang.TabIndex = 18
        Me.Lang.Text = "Languages Known:"
        '
        'join
        '
        Me.join.AutoSize = True
        Me.join.Location = New System.Drawing.Point(1, 559)
        Me.join.Name = "join"
        Me.join.Size = New System.Drawing.Size(69, 13)
        Me.join.TabIndex = 19
        Me.join.Text = "Joining Date:"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(175, 2)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 20)
        Me.TextBox1.TabIndex = 20
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(175, 32)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(100, 20)
        Me.TextBox2.TabIndex = 21
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(175, 155)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(100, 20)
        Me.TextBox3.TabIndex = 22
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(175, 129)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(100, 20)
        Me.TextBox4.TabIndex = 23
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Location = New System.Drawing.Point(175, 210)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(228, 48)
        Me.RichTextBox1.TabIndex = 24
        Me.RichTextBox1.Text = ""
        '
        'RichTextBox2
        '
        Me.RichTextBox2.Location = New System.Drawing.Point(175, 317)
        Me.RichTextBox2.Name = "RichTextBox2"
        Me.RichTextBox2.Size = New System.Drawing.Size(228, 48)
        Me.RichTextBox2.TabIndex = 25
        Me.RichTextBox2.Text = ""
        '
        'RichTextBox3
        '
        Me.RichTextBox3.Location = New System.Drawing.Point(175, 264)
        Me.RichTextBox3.Name = "RichTextBox3"
        Me.RichTextBox3.Size = New System.Drawing.Size(228, 47)
        Me.RichTextBox3.TabIndex = 26
        Me.RichTextBox3.Text = ""
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(175, 412)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(100, 20)
        Me.TextBox5.TabIndex = 27
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(175, 386)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(100, 20)
        Me.TextBox6.TabIndex = 28
        '
        'TextBox7
        '
        Me.TextBox7.Location = New System.Drawing.Point(175, 444)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(100, 20)
        Me.TextBox7.TabIndex = 29
        '
        'TextBox8
        '
        Me.TextBox8.Location = New System.Drawing.Point(175, 473)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(100, 20)
        Me.TextBox8.TabIndex = 30
        '
        'TextBox9
        '
        Me.TextBox9.Location = New System.Drawing.Point(175, 503)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(100, 20)
        Me.TextBox9.TabIndex = 31
        '
        'TextBox10
        '
        Me.TextBox10.Location = New System.Drawing.Point(175, 529)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(100, 20)
        Me.TextBox10.TabIndex = 32
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.Location = New System.Drawing.Point(185, 605)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(75, 17)
        Me.RadioButton1.TabIndex = 33
        Me.RadioButton1.TabStop = True
        Me.RadioButton1.Text = "Temporary"
        Me.RadioButton1.UseVisualStyleBackColor = True
        '
        'RadioButton2
        '
        Me.RadioButton2.AutoSize = True
        Me.RadioButton2.Location = New System.Drawing.Point(103, 605)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(76, 17)
        Me.RadioButton2.TabIndex = 34
        Me.RadioButton2.TabStop = True
        Me.RadioButton2.Text = "Permanent"
        Me.RadioButton2.UseVisualStyleBackColor = True
        '
        'DateTimePicker2
        '
        Me.DateTimePicker2.Location = New System.Drawing.Point(175, 555)
        Me.DateTimePicker2.Name = "DateTimePicker2"
        Me.DateTimePicker2.Size = New System.Drawing.Size(200, 20)
        Me.DateTimePicker2.TabIndex = 39
        '
        'ListBox3
        '
        Me.ListBox3.FormattingEnabled = True
        Me.ListBox3.Items.AddRange(New Object() {"Married", "Unmarried"})
        Me.ListBox3.Location = New System.Drawing.Point(175, 582)
        Me.ListBox3.Name = "ListBox3"
        Me.ListBox3.Size = New System.Drawing.Size(104, 17)
        Me.ListBox3.Sorted = True
        Me.ListBox3.TabIndex = 41
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(175, 184)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(200, 20)
        Me.DateTimePicker1.TabIndex = 42
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(214, 636)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 43
        Me.Button1.Text = "SAVE"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(363, 636)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 44
        Me.Button2.Text = "Clear"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'ListBox1
        '
        Me.ListBox1.DataBindings.Add(New System.Windows.Forms.Binding("SelectionMode", Global.Mess_Management_System.My.MySettings.Default, "Text", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Items.AddRange(New Object() {"A", "B", "C", "D"})
        Me.ListBox1.Location = New System.Drawing.Point(175, 98)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.SelectionMode = Global.Mess_Management_System.My.MySettings.Default.Text
        Me.ListBox1.Size = New System.Drawing.Size(135, 17)
        Me.ListBox1.Sorted = True
        Me.ListBox1.TabIndex = 36
        '
        'ListBox2
        '
        Me.ListBox2.FormattingEnabled = True
        Me.ListBox2.Items.AddRange(New Object() {"CVR", "KG", "Malviya", "Meera", "RPA", "SR", "SV", "VKB"})
        Me.ListBox2.Location = New System.Drawing.Point(175, 70)
        Me.ListBox2.Name = "ListBox2"
        Me.ListBox2.Size = New System.Drawing.Size(65, 17)
        Me.ListBox2.Sorted = True
        Me.ListBox2.TabIndex = 45
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(494, 102)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 46
        Me.Button3.Text = "See Details"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'TextBox11
        '
        Me.TextBox11.Location = New System.Drawing.Point(588, 238)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(100, 20)
        Me.TextBox11.TabIndex = 47
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(511, 245)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(41, 13)
        Me.Label1.TabIndex = 48
        Me.Label1.Text = "Search"
        '
        'FormPersonalDetails
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.Gainsboro
        Me.ClientSize = New System.Drawing.Size(786, 671)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TextBox11)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.ListBox2)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.ListBox3)
        Me.Controls.Add(Me.DateTimePicker2)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.RadioButton2)
        Me.Controls.Add(Me.RadioButton1)
        Me.Controls.Add(Me.TextBox10)
        Me.Controls.Add(Me.TextBox9)
        Me.Controls.Add(Me.TextBox8)
        Me.Controls.Add(Me.TextBox7)
        Me.Controls.Add(Me.TextBox6)
        Me.Controls.Add(Me.TextBox5)
        Me.Controls.Add(Me.RichTextBox3)
        Me.Controls.Add(Me.RichTextBox2)
        Me.Controls.Add(Me.RichTextBox1)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.join)
        Me.Controls.Add(Me.Lang)
        Me.Controls.Add(Me.National)
        Me.Controls.Add(Me.Nam)
        Me.Controls.Add(Me.Marry)
        Me.Controls.Add(Me.Emer)
        Me.Controls.Add(Me.Contact)
        Me.Controls.Add(Me.Years)
        Me.Controls.Add(Me.Perma)
        Me.Controls.Add(Me.curr)
        Me.Controls.Add(Me.Education)
        Me.Controls.Add(Me.DOB)
        Me.Controls.Add(Me.Mother)
        Me.Controls.Add(Me.father)
        Me.Controls.Add(Me.grade)
        Me.Controls.Add(Me.current)
        Me.Controls.Add(Me.MSRN)
        Me.Controls.Add(Me.Employement)
        Me.Controls.Add(Me.Names)
        Me.Name = "FormPersonalDetails"
        Me.Text = "Personal Details"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Names As System.Windows.Forms.Label
    Friend WithEvents Employement As System.Windows.Forms.Label
    Friend WithEvents MSRN As System.Windows.Forms.Label
    Friend WithEvents current As System.Windows.Forms.Label
    Friend WithEvents grade As System.Windows.Forms.Label
    Friend WithEvents father As System.Windows.Forms.Label
    Friend WithEvents Mother As System.Windows.Forms.Label
    Friend WithEvents DOB As System.Windows.Forms.Label
    Friend WithEvents Education As System.Windows.Forms.Label
    Friend WithEvents curr As System.Windows.Forms.Label
    Friend WithEvents Perma As System.Windows.Forms.Label
    Friend WithEvents Years As System.Windows.Forms.Label
    Friend WithEvents Contact As System.Windows.Forms.Label
    Friend WithEvents Emer As System.Windows.Forms.Label
    Friend WithEvents Marry As System.Windows.Forms.Label
    Friend WithEvents Nam As System.Windows.Forms.Label
    Friend WithEvents National As System.Windows.Forms.Label
    Friend WithEvents Lang As System.Windows.Forms.Label
    Friend WithEvents join As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents RichTextBox1 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox2 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox3 As System.Windows.Forms.RichTextBox
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox10 As System.Windows.Forms.TextBox
    Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton2 As System.Windows.Forms.RadioButton
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents DateTimePicker2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents ListBox3 As System.Windows.Forms.ListBox
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents ListBox2 As System.Windows.Forms.ListBox
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents TextBox11 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label

End Class

