﻿Imports MySql.Data.MySqlClient



Public Class FormDependantDetails
    Dim conn As New connection


    Private Sub FormDependantDetails_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TextBox1.Focus()
    End Sub
    Private Sub textbox1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox1.KeyPress
        If Asc(e.KeyChar) = Keys.Enter Then
            TextBox1.ReadOnly = True
            TextBox4.Focus()
        End If
    End Sub
    Private Sub textbox8_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox8.KeyPress
        If Asc(e.KeyChar) = Keys.Enter Then
            TextBox10.Focus()
            Try
                conn.connect()
                Dim dr As MySqlDataReader
                Dim query As String
                query = "Insert into dependant values ('" + TextBox4.Text + "' ,'" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox1.Text + "','" + TextBox7.Text + "','" + TextBox6.Text + "','" + TextBox5.Text + "','" + TextBox9.Text + "','" + TextBox8.Text + "')"
                Dim comm2 As New MySqlCommand(query, conn.conn)
                dr = comm2.ExecuteReader
            Catch de As MySqlException
                MsgBox("Error Occured! Please Try Again!")
                MsgBox(de.Message.ToString)
                TextBox1.Text = ""
            End Try
        End If

    End Sub
    Private Sub textbox43_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox43.KeyPress
        If Asc(e.KeyChar) = Keys.Enter Then
            TextBox11.Focus()

            Try
                conn.connect()
                Dim dr As MySqlDataReader
                Dim query As String
                query = "Insert into dependant values ('" + TextBox10.Text + "' ,'" + TextBox19.Text + "','" + TextBox23.Text + "','" + TextBox1.Text + "','" + TextBox27.Text + "','" + TextBox32.Text + "','" + TextBox37.Text + "','" + TextBox35.Text + "','" + TextBox43.Text + "')"
                Dim comm2 As New MySqlCommand(query, conn.conn)
                dr = comm2.ExecuteReader
            Catch de As MySqlException
                MsgBox("Error Occured! Please Try Again!")
                MsgBox(de.Message.ToString)
                TextBox1.Text = ""
            End Try
        End If

    End Sub

    Private Sub textbox42_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox42.KeyPress
        If Asc(e.KeyChar) = Keys.Enter Then
            TextBox12.Focus()
            Try
                conn.connect()
                Dim dr As MySqlDataReader
                Dim query As String
                query = "Insert into dependant values ('" + TextBox11.Text + "' ,'" + TextBox18.Text + "','" + TextBox22.Text + "','" + TextBox1.Text + "','" + TextBox26.Text + "','" + TextBox31.Text + "','" + TextBox36.Text + "','" + TextBox30.Text + "','" + TextBox42.Text + "')"
                Dim comm2 As New MySqlCommand(query, conn.conn)
                dr = comm2.ExecuteReader
            Catch de As MySqlException
                MsgBox("Error Occured! Please Try Again!")
                MsgBox(de.Message.ToString)
                TextBox1.Text = ""
            End Try
        End If

    End Sub

    Private Sub textbox41_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox41.KeyPress
        If Asc(e.KeyChar) = Keys.Enter Then
            Me.Hide()
            Try
                conn.connect()
                Dim dr As MySqlDataReader
                Dim query As String
                query = "Insert into dependant values ('" + TextBox12.Text + "' ,'" + TextBox17.Text + "','" + TextBox21.Text + "','" + TextBox1.Text + "','" + TextBox25.Text + "','" + TextBox14.Text + "','" + TextBox34.Text + "','" + TextBox28.Text + "','" + TextBox41.Text + "')"
                Dim comm2 As New MySqlCommand(query, conn.conn)
                dr = comm2.ExecuteReader
            Catch de As MySqlException
                MsgBox("Error Occured! Please Try Again!")
                MsgBox(de.Message.ToString)
                TextBox1.Text = ""
            End Try
        End If

    End Sub

    
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub
End Class