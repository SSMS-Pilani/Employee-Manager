﻿Public Class formControlP
    Public Logged_User As String = formLogin.Logged_User

    'Various KeyEvents
    Private Sub formControlP_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        Select Case (e.KeyCode)
            Case Keys.Escape
                Me.Close()
            Case Keys.F5
                formPersonalDetails.Show()
            Case Keys.Q
                Dim myNum As String

                Try
                    myNum = InputBox("Who are you : ")
                    If myNum = "" Then
                        MsgBox("Enter Proper Password")
                    ElseIf myNum = "devenbansod.bits" Then
                        formEditSettings.Show()
                    Else
                        MsgBox("Enter Proper Password")
                    End If

                Catch
                    MsgBox("Enter Proper Password!.")

                End Try

        End Select
    End Sub

    'Needs To act upon the Key Events of Form
    Private Sub formControlP_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.KeyPreview = True
    End Sub


    'Below Functions handle various Buttons' Clicks'


    Private Sub Add_Item_Click(sender As Object, e As EventArgs) Handles Add_item.Click
        formLeaves.Show()
    End Sub


    Private Sub Extras_Click(sender As Object, e As EventArgs) Handles Extras.Click
        formPersonalDetails.Show()
    End Sub




    Private Sub Monthly_bill_Click(sender As Object, e As EventArgs) Handles Monthly_Bill.Click
        formEdit.Show()
    End Sub




    Private Sub Grub_Signings_Click(sender As Object, e As EventArgs) Handles Grub_Signings.Click
        formDependantDetails.Show()
    End Sub


End Class